import { useEffect, useMemo, useState } from 'react';
import { exportReportPdf, generateReport, getDemoTopology, runEnvironmentCheck, scanDemoRepo, scanRepo } from './api';
import { EvidenceReplay } from './components/EvidenceReplay';
import { FindingList } from './components/FindingList';
import { ForgeTopology } from './components/ForgeTopology';
import { ScoreGauge } from './components/ScoreGauge';
import type { ClaimLedger, Finding, ScanResponse, ScoreBreakdown, TopologyGraph } from './types';

// Embedded CSS for instant Golden Dark UI Overhaul
const GLOBAL_STYLES = `
  :root {
    --bg-base: #050505;
    --bg-panel: rgba(15, 15, 15, 0.65);
    --bg-panel-solid: #0f0f0f;
    --gold-primary: #C9A227;
    --gold-light: #E0BC4A;
    --gold-glow: rgba(201, 162, 39, 0.4);
    --text-main: #F5F1E8;
    --text-muted: #8a8478;
    --status-pass: #22C55E;
    --status-warn: #F97316;
    --status-fail: #EF4444;
    --border-subtle: 1px solid rgba(201, 162, 39, 0.15);
    --border-glow: 1px solid rgba(201, 162, 39, 0.4);
    --glow-sm: 0 0 10px rgba(201, 162, 39, 0.1);
    --glow-md: 0 0 20px rgba(201, 162, 39, 0.2);
  }
  * { box-sizing: border-box; }
  body, html, #root { margin: 0; padding: 0; background: var(--bg-base); color: var(--text-main); font-family: 'Inter', system-ui, sans-serif; height: 100%; overflow-x: hidden; }
  .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }
  
  /* Layout */
  .app-shell { display: flex; flex-direction: column; height: 100vh; background: radial-gradient(circle at 50% 0%, #141414 0%, #050505 60%); }
  .topbar { display: flex; justify-content: space-between; align-items: center; padding: 16px 32px; background: rgba(10, 10, 10, 0.8); backdrop-filter: blur(10px); border-bottom: var(--border-subtle); z-index: 10; }
  .brand { display: flex; align-items: center; gap: 12px; }
  .brand-mark { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: var(--bg-base); border: 1px solid var(--gold-primary); color: var(--gold-primary); border-radius: 8px; font-weight: bold; box-shadow: var(--glow-md); }
  .brand-title { font-weight: 800; font-size: 16px; letter-spacing: 0.5px; color: var(--text-main); }
  .brand-subtitle { font-size: 11px; color: var(--text-muted); letter-spacing: 1px; text-transform: uppercase; }
  .status-cluster { display: flex; gap: 8px; }
  .status-pill { padding: 4px 10px; font-size: 10px; font-weight: 600; border-radius: 4px; border: 1px solid rgba(201, 162, 39, 0.3); color: var(--gold-light); background: rgba(201, 162, 39, 0.05); text-transform: uppercase; }
  
  .main { display: flex; flex: 1; overflow: hidden; }
  .sidebar { width: 240px; min-width: 240px; border-right: var(--border-subtle); background: rgba(8, 8, 8, 0.6); backdrop-filter: blur(8px); padding: 24px 16px; display: flex; flex-direction: column; gap: 24px; height: 100%; overflow-y: auto; }
  
  /* Centering Fix: Max width and margin auto */
  .content { flex: 1; overflow-y: auto; padding: 32px; display: flex; justify-content: center; scrollbar-width: thin; scrollbar-color: var(--gold-primary) transparent; }
  .content::-webkit-scrollbar { width: 8px; }
  .content::-webkit-scrollbar-thumb { background: var(--gold-primary); border-radius: 4px; }
  .content > div { width: 100%; max-width: 1200px; }
  
  /* Tabs */
  .tabs { display: flex; flex-direction: column; gap: 4px; }
  .tab { text-align: left; background: transparent; border: 1px solid transparent; padding: 12px; border-radius: 8px; cursor: pointer; display: flex; flex-direction: column; gap: 4px; transition: all 0.2s; color: var(--text-muted); }
  .tab:hover { background: rgba(201, 162, 39, 0.05); color: var(--gold-light); }
  .tab.active { background: rgba(201, 162, 39, 0.1); border-color: var(--border-glow); box-shadow: var(--glow-sm); }
  .tab-title { font-weight: 700; font-size: 13px; color: inherit; }
  .tab.active .tab-title { color: var(--gold-primary); }
  .tab-desc { font-size: 11px; color: var(--text-muted); }
  
  /* Panels & Cards */
  .panel { background: var(--bg-panel); backdrop-filter: blur(12px); border: var(--border-subtle); border-radius: 12px; padding: 24px; margin-bottom: 24px; position: relative; overflow: hidden; transition: border-color 0.3s; }
  .panel:hover { border-color: rgba(201, 162, 39, 0.3); }
  .panel::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, var(--gold-primary), transparent); opacity: 0.5; }
  .panel-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; }
  .panel-header h2 { margin: 0; font-size: 18px; font-weight: 700; color: var(--text-main); }
  .panel-subtitle { margin: 4px 0 0 0; font-size: 12px; color: var(--text-muted); }
  .compact-header { margin-bottom: 16px; }
  
  /* Buttons & Inputs */
  .btn { background: transparent; color: var(--gold-primary); border: 1px solid var(--gold-primary); padding: 8px 16px; border-radius: 6px; font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: 600; cursor: pointer; text-transform: uppercase; transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px; }
  .btn:hover { background: rgba(201, 162, 39, 0.1); box-shadow: 0 0 10px rgba(201, 162, 39, 0.2); }
  .btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .btn.primary { background: var(--gold-primary); color: #050505; border-color: var(--gold-primary); }
  .btn.primary:hover { background: var(--gold-light); box-shadow: 0 0 20px var(--gold-glow); }
  .btn.small { padding: 4px 8px; font-size: 10px; }
  
  .input { background: rgba(0,0,0,0.4); border: 1px solid rgba(201, 162, 39, 0.2); color: var(--text-main); padding: 10px 14px; border-radius: 6px; font-size: 13px; flex: 1; outline: none; transition: border 0.2s; }
  .input:focus { border-color: var(--gold-primary); box-shadow: 0 0 8px rgba(201, 162, 39, 0.1); }
  
  /* Audit Dashboard */
  .audit-dashboard-v7, .tab-page { animation: fadeIn 0.4s ease-out; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  .command-panel { display: flex; justify-content: space-between; align-items: center; gap: 24px; background: linear-gradient(135deg, rgba(201, 162, 39, 0.05) 0%, transparent 50%); }
  .eyebrow { font-size: 10px; color: var(--gold-primary); text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 8px; }
  .command-copy h1 { margin: 0 0 8px 0; font-size: 24px; font-weight: 800; }
  .command-copy p { margin: 0; color: var(--text-muted); font-size: 13px; max-width: 500px; }
  .command-actions { display: flex; gap: 8px; align-items: center; }
  
  /* Metrics */
  .metric-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin-bottom: 24px; }
  .metric-card { background: var(--bg-panel); border: 1px solid rgba(201, 162, 39, 0.1); border-radius: 12px; padding: 16px; text-align: center; transition: transform 0.2s; }
  .metric-card:hover { transform: translateY(-2px); border-color: rgba(201, 162, 39, 0.4); }
  .metric-value { font-size: 32px; font-weight: 800; color: var(--gold-primary); margin-bottom: 4px; }
  .metric-card[data-score="pass"] .metric-value { color: var(--status-pass); }
  .metric-card[data-score="warn"] .metric-value { color: var(--status-warn); }
  .metric-card[data-score="fail"] .metric-value { color: var(--status-fail); }
  .metric-title { font-size: 12px; font-weight: 700; text-transform: uppercase; color: var(--text-main); }
  .metric-card p { font-size: 10px; color: var(--text-muted); margin: 4px 0 0 0; }
  
  /* Score Gauge Sidebar */
  .sidebar-score { text-align: center; }
  .sidebar-score-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
  .sidebar-score-head h3 { margin: 0; font-size: 14px; }
  .score-status { font-size: 10px; color: var(--text-muted); text-transform: uppercase; }
  .mini-facts { display: flex; justify-content: space-around; margin-top: 16px; padding-top: 16px; border-top: 1px solid rgba(201, 162, 39, 0.1); }
  .mini-facts div { display: flex; flex-direction: column; align-items: center; }
  .mini-facts span { font-size: 20px; font-weight: 800; color: var(--text-main); }
  .danger-text { color: var(--status-fail) !important; }
  .mini-facts small { font-size: 10px; color: var(--text-muted); text-transform: uppercase; }
  .sidebar-rule { font-size: 9px; text-align: center; color: var(--text-muted); line-height: 1.4; opacity: 0.7; }
  
  /* Finding List - Enlarged for Readability */
  .finding-list-shell { display: flex; flex-direction: column; gap: 16px; }
  .finding-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 16px; margin-bottom: 8px; flex-wrap: wrap; }
  .segmented { display: flex; border: 1px solid rgba(201, 162, 39, 0.2); border-radius: 8px; overflow: hidden; }
  .segmented button { background: transparent; border: none; padding: 10px 16px; color: var(--text-muted); cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 6px; transition: all 0.2s; font-weight: 600; }
  .segmented button.active { background: rgba(201, 162, 39, 0.1); color: var(--gold-primary); }
  .compact-input { max-width: 300px; padding: 8px 12px; font-size: 12px; }
  
  .finding-list { display: flex; flex-direction: column; gap: 16px; }
  .finding-row { background: rgba(20,20,20,0.4); border: 1px solid rgba(201, 162, 39, 0.1); border-radius: 8px; padding: 20px 24px; border-left: 4px solid var(--gold-primary); transition: all 0.2s; }
  .finding-row:hover { border-color: rgba(201, 162, 39, 0.4); background: rgba(25,25,25,0.6); }
  .finding-row.high { border-left-color: var(--status-fail); }
  .finding-row.medium { border-left-color: var(--status-warn); }
  .finding-row.low { border-left-color: var(--gold-primary); }
  
  .finding-mainline { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
  .finding-code-block { display: flex; align-items: center; gap: 12px; }
  .finding-code { font-size: 16px; font-weight: 700; color: var(--gold-light); }
  .finding-category { font-size: 12px; color: var(--text-muted); text-transform: uppercase; background: rgba(255,255,255,0.05); padding: 2px 8px; border-radius: 4px; }
  .badge { padding: 4px 10px; border-radius: 4px; font-size: 11px; font-weight: 700; text-transform: uppercase; font-family: 'JetBrains Mono', monospace; }
  .badge.high { background: rgba(239, 68, 68, 0.15); color: var(--status-fail); border: 1px solid var(--status-fail); }
  .badge.medium { background: rgba(249, 115, 22, 0.15); color: var(--status-warn); border: 1px solid var(--status-warn); }
  .badge.low { background: rgba(201, 162, 39, 0.15); color: var(--gold-primary); border: 1px solid var(--gold-primary); }
  
  .finding-message { margin: 0 0 12px 0; font-size: 15px; color: var(--text-main); line-height: 1.5; }
  .finding-meta { display: flex; gap: 16px; font-size: 12px; color: var(--text-muted); margin-bottom: 16px; }
  .finding-details summary { cursor: pointer; font-size: 13px; color: var(--gold-primary); font-family: 'JetBrains Mono', monospace; font-weight: 600; }
  .snippet { background: #000; padding: 16px; border-radius: 6px; border: 1px solid rgba(201, 162, 39, 0.1); font-size: 13px; overflow-x: auto; margin: 12px 0; }
  
  /* Ledger & Grids - Better Vertical Spacing */
  .ledger-panel { padding: 24px; }
  .ledger-columns { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px; }
  .ledger-card { background: rgba(0,0,0,0.3); border: 1px solid rgba(201, 162, 39, 0.1); border-radius: 8px; padding: 20px; height: 100%; display: flex; flex-direction: column; }
  .ledger-card-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid rgba(201, 162, 39, 0.1); }
  .ledger-card-head h3 { margin: 0; font-size: 15px; }
  .status-dot { width: 10px; height: 10px; border-radius: 50%; }
  .status-dot.pass { background: var(--status-pass); box-shadow: 0 0 8px var(--status-pass); }
  .status-dot.warn { background: var(--status-warn); box-shadow: 0 0 8px var(--status-warn); }
  .status-dot.fail { background: var(--status-fail); box-shadow: 0 0 8px var(--status-fail); }
  .ledger-list { list-style: none; padding: 0; margin: 0; font-size: 13px; color: var(--text-muted); flex: 1; }
  .ledger-list li { padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.03); line-height: 1.4; }
  .ledger-list li:last-child { border-bottom: none; }
  .more-line { font-size: 11px; color: var(--gold-primary); margin-top: 12px; text-align: right; font-weight: 600; }
  
  /* Probe Summary */
  .probe-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 24px; }
  .probe-card { display: flex; flex-direction: column; align-items: center; text-align: center; }
  .probe-card span { font-size: 32px; font-weight: 800; color: var(--gold-primary); }
  .probe-card.pass span { color: var(--status-pass); }
  .probe-card.fail span { color: var(--status-fail); }
  .probe-card strong { font-size: 16px; margin: 6px 0; }
  .probe-card small { font-size: 11px; color: var(--text-muted); }
  
  /* Report & Scope */
  .report-preview-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; }
  @media (max-width: 900px) { .report-preview-grid { grid-template-columns: 1fr; } }
  .report-score { font-size: 56px; font-weight: 800; color: var(--gold-primary); }
  .report-score-denom { font-size: 24px; color: var(--text-muted); }
  .matrix { display: flex; flex-direction: column; gap: 16px; }
  .metric-line { display: flex; align-items: center; gap: 12px; font-size: 13px; }
  .metric-line span { width: 160px; color: var(--text-muted); }
  .metric-line strong { width: 40px; text-align: right; }
  .metric-bar { flex: 1; height: 8px; background: rgba(255,255,255,0.05); border-radius: 4px; overflow: hidden; }
  .metric-bar i { display: block; height: 100%; background: var(--gold-primary); border-radius: 4px; transition: width 0.5s; }
  .metric-bar i[data-score="pass"] { background: var(--status-pass); }
  .metric-bar i[data-score="warn"] { background: var(--status-warn); }
  .metric-bar i[data-score="fail"] { background: var(--status-fail); }
  
  .raw { background: #000; border: 1px solid rgba(201, 162, 39, 0.1); padding: 16px; border-radius: 8px; font-size: 12px; max-height: 400px; overflow-y: auto; color: #a9a9a9; white-space: pre-wrap; }
  .error-banner { background: rgba(239, 68, 68, 0.1); border: 1px solid var(--status-fail); color: var(--status-fail); padding: 12px 24px; display: flex; justify-content: space-between; align-items: center; font-size: 13px; backdrop-filter: blur(10px); }
  .error-banner-dismiss { background: none; border: none; color: var(--status-fail); font-size: 18px; cursor: pointer; }
  
  /* Topology Canvas Overrides */
  .topology-card { background: rgba(0,0,0,0.4); border: 1px solid rgba(201, 162, 39, 0.2); box-shadow: 0 0 30px rgba(0,0,0,0.5) inset; }
  .graph-stage { background: #000; border-radius: 8px; overflow: hidden; position: relative; }
`;

type Tab = 'audit' | 'environment' | 'evidence' | 'report' | 'scope';

const GOLDEN_REPO = 'https://github.com/FabianS10/reaper-eagle-forge-golden-repo';
const DEFAULT_CHECKS = ['PYTHON_VERSION', 'ROCMINFO', 'ROCM_SMI_PRODUCT', 'HIPCC_VERSION', 'PYTORCH_SMOKE_TEST', 'PROFILER_AVAILABILITY'];
const DEFAULT_BREAKDOWN: ScoreBreakdown = { overall: 0, portability: 0, benchmark_integrity: 0, evidence_completeness: 0, claim_discipline: 0 };

export default function App() {
  const [tab, setTab] = useState<Tab>('audit');
  const [repoUrl, setRepoUrl] = useState(GOLDEN_REPO);
  const [scan, setScan] = useState<ScanResponse | null>(null);
  const [topology, setTopology] = useState<TopologyGraph | null>(null);
  const [envResult, setEnvResult] = useState<any | null>(null);
  const [report, setReport] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    scanDemoRepo().then((data) => {
      setScan(data);
      setTopology(data.topology ?? null);
      if (!data.topology) return getDemoTopology().then(setTopology);
      return undefined;
    }).catch(() => undefined);
  }, []);

  const findings: Finding[] = useMemo(() => scan?.findings ?? [], [scan]);
  const breakdown = scan?.score_breakdown ?? DEFAULT_BREAKDOWN;
  const ledger = scan?.claim_ledger ?? null;
  const blockerCount = findings.filter((finding) => finding.severity === 'high').length;
  const reportPayload = useMemo(() => ({
    findings,
    score: scan?.score ?? 0,
    label: scan?.label ?? 'not_checked',
    score_breakdown: scan?.score_breakdown,
    claim_ledger: scan?.claim_ledger,
    hardware_mode: envResult?.mode ?? 'static_scan_or_evidence_replay'
  }), [findings, scan, envResult]);

  async function handleScan(useDemo = false) {
    setBusy(true);
    setErrorMessage(null);
    try {
      const data = useDemo ? await scanDemoRepo() : await scanRepo(repoUrl || GOLDEN_REPO);
      setScan(data);
      setTopology(data.topology ?? null);
      setTab('audit');
    } catch (error) {
      setErrorMessage(`Scan failed: ${error instanceof Error ? error.message : String(error)}. Check the repo URL and that the backend is reachable, or try Demo.`);
    } finally { setBusy(false); }
  }

  async function handleEnvironment() {
    setBusy(true);
    try {
      const data: any = await runEnvironmentCheck(DEFAULT_CHECKS);
      setEnvResult(data);
      setTopology(data.topology ?? topology);
      setTab('environment');
    } catch (error) { setEnvResult({ mode: 'backend_unavailable', error: String(error) }); }
    finally { setBusy(false); }
  }

  async function handleReport() {
    setBusy(true);
    try {
      const data = await generateReport(reportPayload);
      setReport(data);
      setTab('report');
    } catch {
      setReport({ generation_mode: 'client_fallback', markdown: fallbackReport(scan), html: '' });
      setTab('report');
    } finally { setBusy(false); }
  }

  async function handlePdfExport() {
    setBusy(true);
    setErrorMessage(null);
    try { await exportReportPdf(reportPayload); }
    catch (error) { setErrorMessage(`PDF export failed: ${error instanceof Error ? error.message : String(error)}.`); }
    finally { setBusy(false); }
  }

  return (
    <>
      <style>{GLOBAL_STYLES}</style>
      <div className="app-shell">
        <header className="topbar">
          <div className="brand"><div className="brand-mark mono">RF</div><div><div className="brand-title">Reaper Eagle Forge ML</div><div className="brand-subtitle">AMD readiness · benchmark truth · evidence boundaries</div></div></div>
          <div className="status-cluster"><span className="status-pill mono">Static audit</span><span className="status-pill mono">Fixed probes only</span><span className="status-pill mono">Replay ≠ live</span></div>
        </header>

        {errorMessage && (
          <div className="error-banner" role="alert">
            <span>{errorMessage}</span>
            <button className="error-banner-dismiss" onClick={() => setErrorMessage(null)} aria-label="Dismiss error">×</button>
          </div>
        )}

        <main className="main">
          <aside className="sidebar">
            <nav className="tabs">
              <TabButton active={tab === 'audit'} onClick={() => setTab('audit')} title="Audit" desc="Repo readiness" />
              <TabButton active={tab === 'environment'} onClick={() => setTab('environment')} title="Live" desc="Fixed probes" />
              <TabButton active={tab === 'evidence'} onClick={() => setTab('evidence')} title="Replay" desc="MI300X capsule" />
              <TabButton active={tab === 'report'} onClick={() => setTab('report')} title="Report" desc="Decision package" />
              <TabButton active={tab === 'scope'} onClick={() => setTab('scope')} title="Scope" desc="Pitch boundary" />
            </nav>

            <div className="sidebar-score panel">
              <div className="sidebar-score-head"><h3>Forge Score</h3><span className="mono score-status">{scan?.label ?? 'not checked'}</span></div>
              <ScoreGauge score={scan?.score ?? 0} label="" />
              <div className="mini-facts"><div><span className="mono">{findings.length}</span><small>findings</small></div><div><span className="mono danger-text">{blockerCount}</span><small>blockers</small></div></div>
            </div>
            <div className="sidebar-rule mono">Gold = chrome · data state = green / orange / red</div>
          </aside>

          <section className="content">
            {tab === 'audit' && (
              <AuditDashboard busy={busy} repoUrl={repoUrl} setRepoUrl={setRepoUrl} onScan={handleScan} onEnvironment={handleEnvironment} onReport={handleReport} findings={findings} breakdown={breakdown} score={scan?.score ?? 0} label={scan?.label ?? 'not checked'} ledger={ledger} topology={topology} />
            )}

            {tab === 'environment' && (
              <div className="tab-page live-dashboard-v7">
                <section className="panel live-hero">
                  <div><div className="eyebrow mono">safe live path</div><h1>Live AMD Check</h1><p>Fixed ROCm/PyTorch diagnostics only. No arbitrary shell and no scanned repo execution.</p></div>
                  <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}><button className="btn primary wide-action" onClick={handleEnvironment} disabled={busy}>{busy ? 'Running probes…' : 'Run Fixed Probes'}</button></div>
                </section>
                <ProbeSummary result={envResult} />
                <section className="panel raw-panel live-raw-v7">
                  <div className="panel-header compact-header"><h2>Diagnostic JSON</h2><span className="status-pill mono">raw · readable</span></div>
                  <pre className="raw mono readable-output">{envResult ? JSON.stringify(envResult, null, 2) : 'Run fixed probes to populate the diagnostics panel.'}</pre>
                </section>
                <ForgeTopology graph={envResult?.topology ?? topology} variant="overview" />
              </div>
            )}

            {tab === 'evidence' && <EvidenceReplay />}

            {tab === 'report' && (
              <div className="tab-page report-dashboard-v7">
                <section className="panel report-hero-v7">
                  <div><div className="eyebrow mono">decision package</div><h1>Decision Report</h1><p>A judge-readable product report: scores, claim ledger, evidence boundary, and next proof required.</p></div>
                  <div className="report-actions"><button className="btn" onClick={handleReport} disabled={busy}>{busy ? 'Generating…' : 'Refresh Preview'}</button><button className="btn primary" onClick={handlePdfExport} disabled={busy}>Export PDF</button></div>
                </section>
                <ReportPreview scan={scan} ledger={ledger} findings={findings} breakdown={breakdown} report={report} />
              </div>
            )}

            {tab === 'scope' && <ScopeAndPitch />}
          </section>
        </main>
      </div>
    </>
  );
}

function AuditDashboard(props: { busy: boolean; repoUrl: string; setRepoUrl: (value: string) => void; onScan: (useDemo?: boolean) => void; onEnvironment: () => void; onReport: () => void; findings: Finding[]; breakdown: ScoreBreakdown; score: number; label: string; ledger: ClaimLedger | null; topology: TopologyGraph | null }) {
  return (
    <div className="audit-dashboard-v7">
      <section className="panel command-panel audit-command-v7">
        <div className="command-copy"><div className="eyebrow mono">repo scan · readiness · claims</div><h1>AMD-readiness cockpit</h1><p>Static repo audit, benchmark-truth scoring, claim ledger, and a clean evidence graph overview.</p></div>
        <div className="command-actions"><input className="input mono" placeholder="https://github.com/owner/repo" value={props.repoUrl} onChange={(event) => props.setRepoUrl(event.target.value)} /><button className="btn primary" onClick={() => props.onScan(false)} disabled={props.busy}>{props.busy ? 'Scanning…' : 'Scan Repo'}</button><button className="btn" onClick={() => props.onScan(true)} disabled={props.busy}>Demo</button><button className="btn" onClick={props.onEnvironment} disabled={props.busy}>Live</button><button className="btn" onClick={props.onReport} disabled={props.busy}>Report</button></div>
      </section>
      <ScoreBreakdownCards breakdown={props.breakdown} score={props.score} label={props.label} />
      <ForgeTopology graph={props.topology} variant="overview" />
      <section className="panel findings-panel"><div className="panel-header compact-header"><div><h2>Findings</h2><p className="panel-subtitle">Compact audit table. Details stay inside this panel.</p></div><span className="status-pill mono">{props.findings.length} total</span></div><FindingList findings={props.findings} /></section>
      <ClaimLedgerPanel ledger={props.ledger} compact />
    </div>
  );
}

function TabButton({ active, onClick, title, desc }: { active: boolean; onClick: () => void; title: string; desc: string }) {
  return <button className={`tab ${active ? 'active' : ''}`} onClick={onClick}><span className="tab-title">{title}</span><span className="tab-desc">{desc}</span></button>;
}

function ScoreBreakdownCards({ breakdown, score, label }: { breakdown: ScoreBreakdown; score: number; label: string }) {
  const items = [['Overall', score, label], ['Portability', breakdown.portability, 'CUDA/NVIDIA lock-in'], ['Benchmark', breakdown.benchmark_integrity, 'warm-up · sync · p95'], ['Evidence', breakdown.evidence_completeness, 'Docker · manifest · hashes'], ['Claims', breakdown.claim_discipline, 'allowed vs blocked']] as const;
  return <div className="metric-grid">{items.map(([title, value, desc]) => <div className="metric-card" key={title} data-score={scoreClass(value)}><div className="metric-value mono">{value}</div><div className="metric-title">{title}</div><p>{desc}</p></div>)}</div>;
}

function ClaimLedgerPanel({ ledger, compact = false }: { ledger: ClaimLedger | null; compact?: boolean }) {
  if (!ledger) return <section className="panel ledger-panel"><div className="panel-header compact-header"><h2>Claim Ledger</h2><span className="status-pill mono">waiting</span></div><p>Run a scan to load allowed claims, blocked claims, verified facts, and required proof.</p></section>;
  return <section className={`panel ledger-panel ${compact ? 'compact-ledger' : ''}`}><div className="panel-header compact-header"><div><h2>Claim Ledger</h2><p className="panel-subtitle">What the product is allowed to say from this evidence.</p></div><span className="status-pill mono">strict</span></div><div className="ledger-columns"><LedgerCard title="Allowed" items={ledger.allowed_claims} kind="pass" /><LedgerCard title="Blocked" items={ledger.blocked_claims.length ? ledger.blocked_claims : ['No blocked claim loaded yet.']} kind={ledger.blocked_claims.length ? 'fail' : 'pass'} /><LedgerCard title="Verified" items={ledger.verified_claims} kind="pass" /><LedgerCard title="Next Proof" items={ledger.required_next_evidence.length ? ledger.required_next_evidence : ['No additional evidence requirement detected.']} kind="warn" /></div></section>;
}

function LedgerCard({ title, items, kind }: { title: string; items: string[]; kind: 'pass' | 'warn' | 'fail' }) {
  return <div className={`ledger-card ${kind}`}><div className="ledger-card-head"><h3>{title}</h3><span className={`status-dot ${kind}`} /></div><ul className="ledger-list compact-list">{items.slice(0, 3).map((item) => <li key={item}>{item}</li>)}</ul>{items.length > 3 && <div className="more-line mono">+{items.length - 3} more</div>}</div>;
}

function ProbeSummary({ result }: { result: any | null }) {
  const checks = result?.results ?? [];
  const passed = checks.filter((check: any) => check.status === 'passed').length;
  const failed = checks.filter((check: any) => check.status === 'failed' || check.status === 'not_available').length;
  return <section className="probe-grid"><div className="panel probe-card"><span className="mono">{checks.length || DEFAULT_CHECKS.length}</span><strong>Fixed checks</strong><small>No arbitrary shell.</small></div><div className="panel probe-card pass"><span className="mono">{passed}</span><strong>Passed</strong><small>Server-side only.</small></div><div className="panel probe-card fail"><span className="mono">{failed}</span><strong>Missing/failed</strong><small>Still safe to report.</small></div></section>;
}

function ReportPreview({ scan, ledger, findings, breakdown }: { scan: ScanResponse | null; ledger: ClaimLedger | null; findings: Finding[]; breakdown: ScoreBreakdown; report: any | null }) {
  const blockers = findings.filter((finding) => finding.severity === 'high').slice(0, 4);
  const next = ledger?.required_next_evidence?.slice(0, 4) ?? [];
  return <div className="report-preview-grid"><section className="panel report-score-card"><div className="eyebrow mono">current verdict</div><div className="report-score-row"><div><span className="report-score mono">{scan?.score ?? 0}</span><span className="report-score-denom">/100</span></div><div><h2>{scan?.label ?? 'Not checked'}</h2><p>Forge is not certifying benchmark superiority. It is certifying what is verified, risky, or blocked by the evidence.</p></div></div></section><section className="panel score-matrix"><h2>Score Matrix</h2><div className="matrix"><MetricLine title="Portability" value={breakdown.portability} /><MetricLine title="Benchmark integrity" value={breakdown.benchmark_integrity} /><MetricLine title="Evidence completeness" value={breakdown.evidence_completeness} /><MetricLine title="Claim discipline" value={breakdown.claim_discipline} /></div></section><section className="panel report-summary-card"><h2>Executive Summary</h2><p>Forge turns CUDA-centered ML repositories and benchmark claims into AMD-readiness evidence packages. Repo Scan is static analysis only; Live Check uses fixed Forge diagnostics; Evidence Replay is never presented as live GPU execution.</p><div className="summary-callout">The product does not ask judges to trust a benchmark number. It shows what code path, environment path, and claim boundary exist.</div></section><section className="panel blockers-card"><h2>Top Blockers</h2>{blockers.length ? <ul className="clean-list">{blockers.map((finding) => <li key={finding.code}><strong>{finding.code}</strong><span>{finding.message}</span></li>)}</ul> : <p>No high-severity blockers loaded.</p>}</section><section className="panel next-proof-card"><h2>Next Proof Required</h2>{next.length ? <ul className="clean-list">{next.map((item) => <li key={item}>{item}</li>)}</ul> : <p>No next-proof list loaded.</p>}</section><ClaimLedgerPanel ledger={ledger} /></div>;
}

function MetricLine({ title, value }: { title: string; value: number }) {
  return <div className="metric-line"><span>{title}</span><strong className="mono">{value}</strong><div className="metric-bar"><i style={{ width: `${Math.max(4, Math.min(100, value))}%` }} data-score={scoreClass(value)} /></div></div>;
}

function ScopeAndPitch() {
  return <div className="tab-page scope-page-v7"><section className="panel hero-panel" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start' }}><div className="eyebrow mono">pitch boundary</div><h1>Forge is a product, not a benchmark contest.</h1><p>Benchmark evidence proves the product is real. The product is the trust layer around AMD migration and benchmark claims.</p></section><div className="scope-grid"><div className="panel"><h2>Forge is</h2><ul className="ledger-list"><li>An AMD-readiness auditor for ML repositories.</li><li>A benchmark-integrity checker for warm-up, sync, repeated trials, and provenance.</li><li>An evidence package generator with live/replay boundaries.</li><li>A decision-support tool for teams considering AMD migration.</li></ul></div><div className="panel"><h2>Forge is not</h2><ul className="ledger-list"><li>Not a raw speed leaderboard.</li><li>Not a generic CUDA-to-ROCm copilot clone.</li><li>Not a universal claim that AMD beats NVIDIA.</li><li>Not an arbitrary user-code execution service.</li></ul></div></div><div className="panel deck-line"><h2>Deck-ready one-liner</h2><p>Reaper Eagle Forge turns CUDA-centered ML repos and benchmark claims into auditable AMD-readiness evidence packages.</p></div></div>;
}

function scoreClass(score: number) { if (score >= 75) return 'pass'; if (score >= 50) return 'warn'; return 'fail'; }
function fallbackReport(scan: ScanResponse | null) { return `# Reaper Eagle Forge ML Report\n\nOverall Forge Score: ${scan?.score ?? 0}/100\nStatus: ${scan?.label ?? 'not checked'}\n\nRepository code was not executed. Live diagnostics are fixed server-side probes only. Replayed evidence must not be presented as a live GPU claim.`; }