import { useEffect, useState } from 'react';
import { getEvidenceReplay } from '../api';
import type { EvidenceReplay as EvidenceReplayType } from '../types';
import { ForgeTopology } from './ForgeTopology';

const EVIDENCE_FILES = [
  ['benchmark', 'benchmark_results.json'],
  ['integrity', 'sha256_manifest.txt'],
  ['environment', 'pytorch_rocm_smoke_test.txt'],
  ['environment', 'rocminfo.txt'],
  ['environment', 'rocm_smi.txt'],
  ['profiler', 'rocprofv3_summary.txt'],
  ['profiler', 'torch_profiler_fallback.txt']
];

export function EvidenceReplay() {
  const [evidence, setEvidence] = useState<EvidenceReplayType | null>(null);
  const [raw, setRaw] = useState<Record<string, string>>({});
  const [selectedFile, setSelectedFile] = useState<string>('benchmark/benchmark_results.json');

  useEffect(() => {
    getEvidenceReplay().then(async (data) => {
      setEvidence(data);
      const base = data.base_path?.startsWith('/api') ? data.base_path : '/forge_evidence';
      const entries = await Promise.all(EVIDENCE_FILES.map(async ([section, file]) => {
        const key = `${section}/${file}`;
        const url = `${base}/${section}/${file}`;
        try { return [key, await fetch(url).then((response) => response.text())] as const; }
        catch { return [key, 'Unavailable in this deployment.'] as const; }
      }));
      setRaw(Object.fromEntries(entries));
    }).catch(() => undefined);
  }, []);

  if (!evidence) {
    return <div className="tab-page loading-page"><div className="panel"><p>Loading evidence capsule...</p></div></div>;
  }

  const metadata = (evidence.metadata ?? {}) as any;
  const fileNames = Object.keys(raw);

  return (
    <div className="tab-page replay-dashboard-v7">
      <section className="panel replay-hero">
        <div>
          <div className="eyebrow mono">replay capsule · not live GPU telemetry</div>
          <h1>Captured MI300X Evidence Replay</h1>
          <p>Use this capsule to prove Forge can attach real AMD evidence without pretending replayed logs are live execution.</p>
        </div>
        <div className="replay-stats">
          <Stat label="GPU" value={metadata.hardware?.gpu ?? 'AMD Instinct MI300X'} />
          <Stat label="Provider" value={metadata.hardware?.provider ?? 'AMD Developer Cloud'} />
          <Stat label="Mode" value="replay only" />
        </div>
      </section>

      <section className="panel raw-evidence-panel evidence-wide">
        <div className="panel-header compact-header">
          <div><h2>Raw Evidence Files</h2><p className="panel-subtitle">Large readable output panel. Hash manifest, benchmark, environment, and profiler artifacts.</p></div>
          <a className="btn small" href="/forge_evidence/integrity/sha256_manifest.txt" download>Download hash manifest</a>
        </div>
        <div className="evidence-file-tabs">
          {fileNames.map((name) => (
            <button key={name} className={selectedFile === name ? 'active' : ''} onClick={() => setSelectedFile(name)}>
              {name}
            </button>
          ))}
        </div>
        <pre className="raw mono evidence-raw readable-output">{raw[selectedFile] ?? 'Select evidence file.'}</pre>
      </section>

      <ForgeTopology graph={evidence.topology} variant="overview" />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return <div className="stat-card panel" style={{ padding: '12px', textAlign: 'center' }}><span style={{ display: 'block', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>{label}</span><strong style={{ display: 'block', fontSize: '14px', color: 'var(--gold-primary)', marginTop: '4px' }}>{value}</strong></div>;
}