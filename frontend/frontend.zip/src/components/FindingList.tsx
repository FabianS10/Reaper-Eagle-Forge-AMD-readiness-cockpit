import { useMemo, useState } from 'react';
import type { Finding } from '../types';

type Filter = 'all' | 'high' | 'medium' | 'low';

const LABELS: Record<Filter, string> = {
  all: 'All',
  high: 'Blockers',
  medium: 'Warnings',
  low: 'Notes'
};

export function FindingList({ findings }: { findings: Finding[] }) {
  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');

  const counts = useMemo(() => ({
    all: findings.length,
    high: findings.filter((finding) => finding.severity === 'high').length,
    medium: findings.filter((finding) => finding.severity === 'medium').length,
    low: findings.filter((finding) => finding.severity === 'low').length
  }), [findings]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return findings.filter((finding) => {
      if (filter !== 'all' && finding.severity !== filter) return false;
      if (!q) return true;
      return [finding.code, finding.category, finding.file_path, finding.message, finding.suggestion]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(q));
    });
  }, [findings, filter, query]);

  if (!findings.length) return <p style={{ padding: '24px 0', color: 'var(--text-muted)' }}>No findings loaded yet. Run a repo scan to populate the audit table.</p>;

  return (
    <div className="finding-list-shell">
      <div className="finding-toolbar">
        <div className="segmented">
          {(Object.keys(LABELS) as Filter[]).map((key) => (
            <button key={key} className={filter === key ? 'active' : ''} onClick={() => setFilter(key)}>
              <span>{LABELS[key]}</span>
              <b className="mono">{counts[key]}</b>
            </button>
          ))}
        </div>
        <input className="input mono compact-input" placeholder="Filter code, file, category..." value={query} onChange={(event) => setQuery(event.target.value)} />
      </div>

      <div className="finding-list" role="list">
        {!visible.length && <p className="empty-state" style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)' }}>No findings match this filter. Try "All" or clear the search.</p>}
        {visible.map((finding, index) => (
          <article className={`finding-row ${finding.severity}`} key={`${finding.code}-${index}`} role="listitem">
            <div className="finding-mainline">
              <div className="finding-code-block">
                <span className="mono finding-code">{finding.code}</span>
                <span className="mono finding-category">{finding.category.replace(/_/g, ' ')}</span>
              </div>
              <span className={`badge ${finding.severity}`}>{finding.severity}</span>
            </div>
            <p className="finding-message">{finding.message}</p>
            <div className="finding-meta mono">
              <span>{finding.file_path ? `${finding.file_path}:${finding.line_number ?? '?'}` : 'repo-level evidence'}</span>
              {finding.status && <span style={{ marginLeft: '16px' }}>{finding.status}</span>}
            </div>
            <details className="finding-details">
              <summary>Snippet & suggested fix</summary>
              {finding.snippet && <pre className="snippet mono">{finding.snippet}</pre>}
              <p style={{ fontSize: '14px', color: 'var(--text-main)' }}><strong>Suggested fix:</strong> {finding.suggestion}</p>
            </details>
          </article>
        ))}
      </div>
    </div>
  );
}