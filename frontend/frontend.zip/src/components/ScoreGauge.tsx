interface ScoreGaugeProps {
  score: number;
  label: string;
}

function statusColor(score: number): string {
  if (score >= 70) return 'var(--status-pass)';
  if (score >= 50) return 'var(--status-warn)';
  return 'var(--status-fail)';
}

export function ScoreGauge({ score, label }: ScoreGaugeProps) {
  const radius = 78;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.max(0, Math.min(100, score)) / 100) * circumference;
  
  return (
    <div className="score-wrap">
      <div className="score-gauge">
        <svg className="score-svg" viewBox="0 0 188 188">
          <defs>
            <linearGradient id="gradScore" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#C9A227" />
              <stop offset="100%" stopColor="#E0BC4A" />
            </linearGradient>
            <filter id="glowScore" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          <circle cx="94" cy="94" r={radius} fill="none" stroke="#2E2A20" strokeWidth="12" />
          <circle
            cx="94"
            cy="94"
            r={radius}
            fill="none"
            stroke="url(#gradScore)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            filter="url(#glowScore)"
            style={{ transition: 'stroke-dashoffset 1s ease-out' }}
          />
        </svg>
        <div className="score-number" style={{ color: statusColor(score), textShadow: '0 0 15px rgba(201, 162, 39, 0.5)' }}>{score}</div>
      </div>
      <div className="score-label mono">{label}</div>
    </div>
  );
}